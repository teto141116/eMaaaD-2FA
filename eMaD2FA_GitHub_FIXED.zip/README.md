# eMaD 2FA

A small Kotlin + Jetpack Compose TOTP authenticator with secure local storage and an optional clipboard-to-notification workflow.

## Important Android limitation

The requested workflow — reading a copied `otpauth://` URI while the application is completely in the background on modern Android — cannot be implemented by a normal third-party app using public, privacy-compliant APIs.

Android 10 (API 29) and newer restrict clipboard access for background applications. A foreground service does **not** turn a normal app into an allowed clipboard reader. Therefore this project deliberately does not use accessibility services, overlays, root, hidden APIs, or other bypasses.

With **Automatic Monitoring ON**:
- When eMaD 2FA is visible, newly copied `otpauth://totp/...` text is detected.
- The URI is validated and parsed.
- The TOTP is stored locally and shown in a normal notification.
- When the app is not visible on Android 10+, the system can block clipboard access.

With **Automatic Monitoring OFF**:
- No clipboard listener is installed.
- Copied content is ignored by this app.

The manual authenticator remains available at all times.

## Security

TOTP secrets are encrypted locally using an AES-GCM key held in Android Keystore. No network, account, analytics, or tracking is used.

## Build

Open the project in Android Studio and build the `app` module.
