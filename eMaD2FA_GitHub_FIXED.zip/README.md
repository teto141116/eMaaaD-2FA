# eMaD 2FA

Final build features:
- Share an `otpauth://` TOTP link to eMaD 2FA and receive the current OTP immediately.
- Live notification updates the OTP and countdown every second.
- Notification actions: Copy Code and Copy Auth Link (or Copy Secret when only a secret was shared).
- Auth links are stored locally in encrypted storage with the account data.
- Manual Add Account remains available.
- EM app logo included.
