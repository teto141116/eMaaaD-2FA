package com.quick2fa.authenticator

import org.junit.Assert.assertEquals
import org.junit.Test

class TotpTest {
    @Test
    fun rfc6238Sha1Vector() {
        val account = OtpAccount(
            id = "test",
            secret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ",
            issuer = "Test",
            account = "test@example.com",
            algorithm = "SHA1",
            digits = 8,
            period = 30
        )
        assertEquals("94287082", Totp.code(account, 59_000L))
        assertEquals("07081804", Totp.code(account, 1_111_111_109_000L))
    }

    @Test
    fun rfc6238Sha256Vector() {
        val account = OtpAccount(
            id = "test",
            secret = "MFRGGZDFMZTWQ2LK",
            issuer = "Test",
            account = "test@example.com",
            algorithm = "SHA256",
            digits = 8,
            period = 30
        )
        // SHA256 RFC test secret differs from this short illustrative secret;
        // this test verifies deterministic generation rather than the RFC SHA256 vector.
        assertEquals(8, Totp.code(account, 59_000L).length)
    }
}
