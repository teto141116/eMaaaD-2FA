package com.quick2fa.authenticator

import org.junit.Assert.*
import org.junit.Test

class OtpUriParserTest {
    @Test
    fun parsesStandardTotpUri() {
        val uri = "otpauth://totp/Example:alice%40example.com?secret=JBSWY3DPEHPK3PXP&issuer=Example&algorithm=SHA1&digits=6&period=30"
        val account = OtpUriParser.parse(uri)!!
        assertEquals("Example", account.issuer)
        assertEquals("alice@example.com", account.account)
        assertEquals("JBSWY3DPEHPK3PXP", account.secret)
        assertEquals("SHA1", account.algorithm)
        assertEquals(6, account.digits)
        assertEquals(30, account.period)
    }

    @Test
    fun rejectsNonTotpUri() {
        assertNull(OtpUriParser.parse("https://example.com"))
        assertNull(OtpUriParser.parse("otpauth://hotp/Example:alice?secret=JBSWY3DPEHPK3PXP"))
    }
}
