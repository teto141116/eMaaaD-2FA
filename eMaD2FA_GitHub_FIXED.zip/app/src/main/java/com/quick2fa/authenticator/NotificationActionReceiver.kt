package com.quick2fa.authenticator

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * Handles notification copy actions.
 *
 * Clipboard writes are intentionally performed once and synchronously. Reading
 * the clipboard back to verify the write can be slow on some Android versions
 * and OEM builds, so it is avoided here. setPrimaryClip() itself is the
 * clipboard write operation and returns immediately after handing the data to
 * Android's ClipboardManager.
 */
class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val appContext = context.applicationContext
        val clipboard = appContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

        when (intent.action) {
            Notifications.ACTION_COPY -> {
                val code = intent.getStringExtra(Notifications.EXTRA_CODE)
                if (code.isNullOrBlank()) return
                copyNow(appContext, clipboard, code, "Code copied")
            }

            Notifications.ACTION_COPY_AUTH -> {
                val auth = intent.getStringExtra(Notifications.EXTRA_AUTH)
                if (auth.isNullOrBlank()) return

                val label = if (auth.startsWith("otpauth://", ignoreCase = true)) {
                    "Auth link copied"
                } else {
                    "Secret copied"
                }
                copyNow(appContext, clipboard, auth, label)
            }
        }
    }

    private fun copyNow(
        context: Context,
        clipboard: ClipboardManager,
        value: String,
        message: String
    ) {
        try {
            clipboard.setPrimaryClip(
                ClipData.newPlainText("eMaD 2FA", value)
            )
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(context, "Copy failed", Toast.LENGTH_SHORT).show()
        }
    }
}
