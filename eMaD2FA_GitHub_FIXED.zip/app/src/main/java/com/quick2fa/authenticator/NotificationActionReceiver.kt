package com.quick2fa.authenticator

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.ClipboardManager
import android.content.ClipData
import android.widget.Toast

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        when (intent.action) {
            Notifications.ACTION_COPY -> {
                val code = intent.getStringExtra(Notifications.EXTRA_CODE) ?: return
                clipboard.setPrimaryClip(ClipData.newPlainText("OTP", code))
                Toast.makeText(context, "Code copied", Toast.LENGTH_SHORT).show()
            }
            Notifications.ACTION_COPY_AUTH -> {
                val auth = intent.getStringExtra(Notifications.EXTRA_AUTH) ?: return
                clipboard.setPrimaryClip(ClipData.newPlainText("Authentication link", auth))
                val label = if (auth.startsWith("otpauth://", ignoreCase = true)) {
                    "Auth link copied"
                } else {
                    "Secret copied"
                }
                Toast.makeText(context, label, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
