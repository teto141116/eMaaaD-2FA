package com.quick2fa.authenticator

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = Prefs(context)

        // Do not perform notification actions while eMaD 2FA is stopped.
        if (!prefs.monitoring) return

        val value = when (intent.action) {
            Notifications.ACTION_COPY -> intent.getStringExtra(Notifications.EXTRA_CODE)
            Notifications.ACTION_COPY_AUTH -> intent.getStringExtra(Notifications.EXTRA_AUTH)
            else -> null
        }?.takeIf { it.isNotEmpty() } ?: return

        val label = when (intent.action) {
            Notifications.ACTION_COPY -> "Code copied"
            Notifications.ACTION_COPY_AUTH ->
                if (value.startsWith("otpauth://", ignoreCase = true)) "Auth link copied"
                else "Secret copied"
            else -> return
        }

        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(
            if (intent.action == Notifications.ACTION_COPY_AUTH) "Authentication link" else "OTP",
            value
        )

        // Set the clip immediately, then retry once shortly after. This makes
        // notification-button copying more reliable on devices that briefly
        // delay clipboard updates while a foreground notification is refreshed.
        clipboard.setPrimaryClip(clip)
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                clipboard.setPrimaryClip(ClipData.newPlainText(
                    if (intent.action == Notifications.ACTION_COPY_AUTH) "Authentication link" else "OTP",
                    value
                ))
            } catch (_: Exception) {
                // The first copy already succeeded on normal devices.
            }
        }, 80L)

        Toast.makeText(context, label, Toast.LENGTH_SHORT).show()
    }
}
