package com.quick2fa.authenticator

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val appContext = context.applicationContext
        val clipboard = appContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

        when (intent.action) {
            Notifications.ACTION_COPY -> {
                val code = intent.getStringExtra(Notifications.EXTRA_CODE)
                if (code.isNullOrBlank()) {
                    pendingResult.finish()
                    return
                }
                copyWithRetry(appContext, clipboard, code) {
                    Toast.makeText(appContext, if (it) "Code copied" else "Copy failed", Toast.LENGTH_SHORT).show()
                    pendingResult.finish()
                }
            }

            Notifications.ACTION_COPY_AUTH -> {
                val auth = intent.getStringExtra(Notifications.EXTRA_AUTH)
                if (auth.isNullOrBlank()) {
                    pendingResult.finish()
                    return
                }
                copyWithRetry(appContext, clipboard, auth) { success ->
                    val label = if (auth.startsWith("otpauth://", ignoreCase = true)) {
                        "Auth link copied"
                    } else {
                        "Secret copied"
                    }
                    Toast.makeText(appContext, if (success) label else "Copy failed", Toast.LENGTH_SHORT).show()
                    pendingResult.finish()
                }
            }

            else -> pendingResult.finish()
        }
    }

    private fun copyWithRetry(
        context: Context,
        clipboard: ClipboardManager,
        value: String,
        done: (Boolean) -> Unit
    ) {
        val handler = Handler(Looper.getMainLooper())
        var attempt = 0

        fun tryCopy() {
            attempt++
            try {
                clipboard.setPrimaryClip(ClipData.newPlainText("eMaD 2FA", value))
                val copied = clipboard.primaryClip
                    ?.getItemAt(0)
                    ?.coerceToText(context)
                    ?.toString() == value

                if (copied || attempt >= 4) {
                    done(copied)
                } else {
                    handler.postDelayed({ tryCopy() }, 80L)
                }
            } catch (_: Exception) {
                if (attempt >= 4) {
                    done(false)
                } else {
                    handler.postDelayed({ tryCopy() }, 80L)
                }
            }
        }

        // Start immediately; retries only happen if the clipboard write was not confirmed.
        tryCopy()
    }
}
