package com.quick2fa.authenticator

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class SecureStore(context: Context) {
    private val prefs = context.getSharedPreferences("quick2fa_secure", Context.MODE_PRIVATE)
    private val alias = "quick2fa_master_key"

    init {
        getOrCreateKey()
    }

    fun loadAccounts(): List<OtpAccount> {
        val encrypted = prefs.getString("accounts", null) ?: return emptyList()
        val json = decrypt(encrypted) ?: return emptyList()
        val array = JSONArray(json)
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(OtpAccount(
                    id = o.getString("id"),
                    secret = o.getString("secret"),
                    issuer = o.optString("issuer"),
                    account = o.getString("account"),
                    algorithm = o.optString("algorithm", "SHA1"),
                    digits = o.optInt("digits", 6),
                    period = o.optInt("period", 30),
                    authUri = o.optString("authUri").takeIf { it.isNotBlank() }
                ))
            }
        }
    }

    fun saveAccounts(accounts: List<OtpAccount>) {
        val array = JSONArray()
        accounts.forEach {
            array.put(JSONObject().apply {
                put("id", it.id); put("secret", it.secret); put("issuer", it.issuer)
                put("account", it.account); put("algorithm", it.algorithm)
                put("digits", it.digits); put("period", it.period)
                if (!it.authUri.isNullOrBlank()) put("authUri", it.authUri)
            })
        }
        prefs.edit().putString("accounts", encrypt(array.toString())).apply()
    }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        gen.init(android.security.keystore.KeyGenParameterSpec.Builder(
            alias,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                    android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return gen.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val data = cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(cipher.iv + data, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String? = try {
        val all = Base64.decode(value, Base64.NO_WRAP)
        val iv = all.copyOfRange(0, 12)
        val data = all.copyOfRange(12, all.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(data), StandardCharsets.UTF_8)
    } catch (_: Exception) { null }
}
