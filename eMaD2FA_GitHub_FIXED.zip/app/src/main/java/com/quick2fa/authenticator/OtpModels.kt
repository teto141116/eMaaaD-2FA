package com.quick2fa.authenticator

data class OtpAccount(
    val id: String,
    val secret: String,
    val issuer: String,
    val account: String,
    val algorithm: String = "SHA1",
    val digits: Int = 6,
    val period: Int = 30
)
