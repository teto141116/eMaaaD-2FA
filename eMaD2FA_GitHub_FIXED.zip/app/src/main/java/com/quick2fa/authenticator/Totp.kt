package com.quick2fa.authenticator

import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object Totp {
    fun code(account: OtpAccount, timeMillis: Long = System.currentTimeMillis()): String {
        val key = base32Decode(account.secret)
        val counter = timeMillis / 1000L / account.period
        val data = ByteBuffer.allocate(8).putLong(counter).array()
        val macName = when (account.algorithm.uppercase()) {
            "SHA256" -> "HmacSHA256"
            "SHA512" -> "HmacSHA512"
            else -> "HmacSHA1"
        }
        val hash = try {
            Mac.getInstance(macName).apply {
                init(SecretKeySpec(key, macName))
            }.doFinal(data)
        } catch (e: GeneralSecurityException) {
            throw IllegalStateException("Unable to generate TOTP", e)
        }
        val offset = hash[hash.size - 1].toInt() and 0x0f
        val binary = ((hash[offset].toInt() and 0x7f) shl 24) or
                ((hash[offset + 1].toInt() and 0xff) shl 16) or
                ((hash[offset + 2].toInt() and 0xff) shl 8) or
                (hash[offset + 3].toInt() and 0xff)
        val modulo = if (account.digits == 8) 100_000_000 else 1_000_000
        return (binary % modulo).toString().padStart(account.digits, '0')
    }

    private fun base32Decode(input: String): ByteArray {
        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
        var buffer = 0
        var bits = 0
        val out = ArrayList<Byte>()
        for (c in input.uppercase()) {
            if (c == '=') break
            val value = alphabet.indexOf(c)
            require(value >= 0) { "Invalid Base32 secret" }
            buffer = (buffer shl 5) or value
            bits += 5
            if (bits >= 8) {
                bits -= 8
                out.add(((buffer shr bits) and 0xff).toByte())
            }
        }
        return out.toByteArray()
    }
}
