package com.quick2fa.authenticator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Quick2FaScreen(
    initialAccounts: List<OtpAccount>,
    monitoring: Boolean,
    onMonitoringChanged: (Boolean) -> Unit,
    onAdd: (String) -> OtpAccount?,
    onDelete: (String) -> Unit
) {
    var accounts by remember { mutableStateOf(initialAccounts) }
    var showAdd by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("eMaD 2FA") }) }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize()
        ) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Automatic Monitoring", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(6.dp))
                    Text(if (monitoring) "Monitoring Active" else "Monitoring Disabled")
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (monitoring) "ON" else "OFF")
                        Switch(checked = monitoring, onCheckedChange = onMonitoringChanged)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Fast setup: from any app, tap Share on the otpauth:// link and choose eMaD 2FA. " +
                        "The account is added automatically and the current code appears in a notification. " +
                        "Clipboard detection still works only while eMaD 2FA is visible on Android 10+.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { showAdd = true },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Add Account") }

            Spacer(Modifier.height(12.dp))
            if (accounts.isEmpty()) {
                Text("No accounts saved.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(accounts, key = { it.id }) { account ->
                        AccountCard(account) {
                            accounts = accounts.filterNot { it.id == account.id }
                            onDelete(account.id)
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddAccountDialog(
            onDismiss = { showAdd = false },
            onAdd = {
                val account = onAdd(it)
                if (account != null) {
                    accounts = accounts.filterNot { a -> a.id == account.id } + account
                    showAdd = false
                }
            }
        )
    }
}

@Composable
private fun AccountCard(account: OtpAccount, onDelete: () -> Unit) {
    val context = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(account.id) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    val code = Totp.code(account, now)
    val remaining = account.period - ((now / 1000L) % account.period)

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(account.issuer.ifBlank { "Authenticator" }, style = MaterialTheme.typography.titleMedium)
            Text(account.account)
            Spacer(Modifier.height(8.dp))
            Text(code, style = MaterialTheme.typography.headlineMedium)
            Text("Expires in ${remaining}s")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cb.setPrimaryClip(ClipData.newPlainText("OTP", code))
                    Toast.makeText(context, "Code copied", Toast.LENGTH_SHORT).show()
                }) { Text("Copy") }
                OutlinedButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

@Composable
private fun AddAccountDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add TOTP Account") },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("otpauth:// URI") },
                minLines = 4
            )
        },
        confirmButton = {
            TextButton(onClick = { onAdd(value) }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
