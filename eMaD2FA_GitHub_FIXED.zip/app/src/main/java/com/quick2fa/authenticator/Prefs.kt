package com.quick2fa.authenticator

import android.content.Context

class Prefs(context: Context) {
    private val p = context.getSharedPreferences("quick2fa", Context.MODE_PRIVATE)

    var monitoring: Boolean
        get() = p.getBoolean("monitoring", false)
        set(value) { p.edit().putBoolean("monitoring", value).apply() }
}
