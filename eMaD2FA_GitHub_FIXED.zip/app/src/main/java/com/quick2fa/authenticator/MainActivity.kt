package com.quick2fa.authenticator

import android.Manifest
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme

class MainActivity : ComponentActivity() {
    private lateinit var store: SecureStore
    private lateinit var prefs: Prefs
    private lateinit var clipboard: ClipboardManager
    private var listener: ClipboardManager.OnPrimaryClipChangedListener? = null

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SecureStore(this)
        prefs = Prefs(this)
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        Notifications.createChannel(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MaterialTheme {
                Quick2FaScreen(
                    initialAccounts = store.loadAccounts(),
                    monitoring = prefs.monitoring,
                    onMonitoringChanged = { prefs.monitoring = it },
                    onAdd = { raw ->
                        val account = OtpUriParser.parse(raw)
                        if (account == null) {
                            Toast.makeText(this, "Invalid TOTP URI", Toast.LENGTH_SHORT).show()
                            null
                        } else {
                            store.saveAccounts(
                                store.loadAccounts().filterNot { it.id == account.id } + account
                            )
                            account
                        }
                    },
                    onDelete = { id ->
                        store.saveAccounts(store.loadAccounts().filterNot { it.id == id })
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (prefs.monitoring) {
            listener = ClipboardManager.OnPrimaryClipChangedListener { processClipboard() }
            clipboard.addPrimaryClipChangedListener(listener!!)
        }
    }

    override fun onPause() {
        listener?.let { clipboard.removePrimaryClipChangedListener(it) }
        listener = null
        super.onPause()
    }

    private fun processClipboard() {
        if (!prefs.monitoring) return
        val clip = clipboard.primaryClip ?: return
        if (clip.description?.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) != true) return
        val text = clip.getItemAt(0).coerceToText(this).toString()
        val account = OtpUriParser.parse(text) ?: return

        store.saveAccounts(store.loadAccounts().filterNot { it.id == account.id } + account)

        val now = System.currentTimeMillis()
        val remaining = account.period - ((now / 1000L) % account.period)
        androidx.core.app.NotificationManagerCompat.from(this).notify(
            Notifications.NOTIFICATION_ID,
            Notifications.notification(this, Totp.code(account, now), remaining)
        )
    }
}
