package com.quick2fa.authenticator

import android.Manifest
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.core.app.NotificationManagerCompat

class MainActivity : ComponentActivity() {
    private lateinit var store: SecureStore
    private lateinit var prefs: Prefs
    private lateinit var clipboard: ClipboardManager
    private var listener: ClipboardManager.OnPrimaryClipChangedListener? = null

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SecureStore(this)
        prefs = Prefs(this)
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        Notifications.createChannel(this)

        requestNotificationPermissionIfNeeded()

        setContent {
            MaterialTheme {
                Quick2FaScreen(
                    initialAccounts = store.loadAccounts(),
                    monitoring = prefs.monitoring,
                    onMonitoringChanged = {
                        prefs.monitoring = it
                        if (!it) OtpNotificationService.stop(this)
                    },
                    onAdd = { raw -> addAccount(raw, notify = true) },
                    onDelete = { id ->
                        store.saveAccounts(store.loadAccounts().filterNot { it.id == id })
                    }
                )
            }
        }

        // Handle a Share/View intent that launched the activity.
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (prefs.monitoring) {
            listener = ClipboardManager.OnPrimaryClipChangedListener { processClipboard() }
            clipboard.addPrimaryClipChangedListener(listener!!)
        }
    }

    override fun onPause() {
        listener?.let { clipboard.removePrimaryClipChangedListener(it) }
        listener = null
        super.onPause()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    /**
     * Receives an otpauth:// URI from Android's Share sheet or from a direct VIEW intent.
     * This does not depend on clipboard access, so it works even when the app was closed.
     */
    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return

        val raw = when (intent.action) {
            Intent.ACTION_SEND -> {
                intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                    ?: intent.dataString
            }
            Intent.ACTION_VIEW -> intent.dataString
            else -> null
        } ?: return

        val trimmed = raw.trim()
        // OtpUriParser also accepts a secret-only share, not just otpauth:// URIs.

        if (!prefs.monitoring) {
            Toast.makeText(
                this,
                "Turn on Automatic Monitoring first",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        addAccount(trimmed, notify = true, fromShare = true)
    }

    private fun addAccount(raw: String, notify: Boolean, fromShare: Boolean = false): OtpAccount? {
        val account = OtpUriParser.parse(raw)
        if (account == null) {
            Toast.makeText(
                this,
                if (fromShare) "Invalid TOTP link or secret" else "Invalid TOTP URI",
                Toast.LENGTH_SHORT
            ).show()
            return null
        }

        store.saveAccounts(
            store.loadAccounts().filterNot { it.id == account.id } + account
        )

        if (notify) {
            showOtpNotification(account)
            OtpNotificationService.start(this, account)
            Toast.makeText(
                this,
                if (fromShare) "OTP ready" else "${account.issuer.ifBlank { "Authenticator" }} added",
                Toast.LENGTH_SHORT
            ).show()
        }

        return account
    }

    private fun showOtpNotification(account: OtpAccount) {
        val now = System.currentTimeMillis()
        val remaining = account.period - ((now / 1000L) % account.period)
        NotificationManagerCompat.from(this).notify(
            Notifications.NOTIFICATION_ID,
            Notifications.notification(this, Totp.code(account, now), remaining, account)
        )
    }

    private fun processClipboard() {
        if (!prefs.monitoring) return
        val clip = clipboard.primaryClip ?: return
        if (clip.description?.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) != true) return
        val text = clip.getItemAt(0).coerceToText(this).toString()
        val account = OtpUriParser.parse(text) ?: return

        store.saveAccounts(store.loadAccounts().filterNot { it.id == account.id } + account)
        showOtpNotification(account)
        OtpNotificationService.start(this, account)
    }
}
