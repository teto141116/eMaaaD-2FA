package com.quick2fa.authenticator

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

object Notifications {
    const val CHANNEL_ID = "2fa_codes"
    const val NOTIFICATION_ID = 2001
    const val ACTION_COPY = "com.quick2fa.COPY"
    const val ACTION_COPY_AUTH = "com.quick2fa.COPY_AUTH"
    const val EXTRA_CODE = "code"
    const val EXTRA_AUTH = "auth"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "2FA Codes", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Current TOTP verification codes" }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun notification(context: Context, code: String, remaining: Long, account: OtpAccount? = null): Notification {
        val copyCode = PendingIntent.getBroadcast(
            context, 11,
            Intent(context, NotificationActionReceiver::class.java).apply {
                action = ACTION_COPY
                putExtra(EXTRA_CODE, code)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val authValue = account?.authUri?.takeIf { it.isNotBlank() } ?: account?.secret
        val copyAuth = authValue?.let { value ->
            PendingIntent.getBroadcast(
                context, 13,
                Intent(context, NotificationActionReceiver::class.java).apply {
                    action = ACTION_COPY_AUTH
                    putExtra(EXTRA_AUTH, value)
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val open = PendingIntent.getActivity(
            context, 12,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle(account?.issuer?.takeIf { it.isNotBlank() } ?: "eMaD 2FA")
            .setContentText("$code • Expires in ${remaining}s")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$code\nExpires in ${remaining}s"))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .addAction(android.R.drawable.ic_menu_save, "Copy Code", copyCode)

        if (copyAuth != null) {
            val label = if (account?.authUri.isNullOrBlank()) "Copy Secret" else "Copy Auth Link"
            builder.addAction(android.R.drawable.ic_menu_share, label, copyAuth)
        }

        builder.addAction(android.R.drawable.ic_menu_view, "Open Authenticator", open)
        return builder.build()
    }
}
