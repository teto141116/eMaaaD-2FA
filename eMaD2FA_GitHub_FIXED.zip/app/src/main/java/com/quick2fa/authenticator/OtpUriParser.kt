package com.quick2fa.authenticator

import android.net.Uri
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

object OtpUriParser {
    fun parse(raw: String): OtpAccount? {
        val uri = try { Uri.parse(raw.trim()) } catch (_: Exception) { return null }
        if (!uri.scheme.equals("otpauth", true) || !uri.host.equals("totp", true)) return null

        val secret = uri.getQueryParameter("secret")?.trim()?.replace(" ", "") ?: return null
        if (!secret.matches(Regex("^[A-Za-z2-7]+=*$", RegexOption.IGNORE_CASE))) return null

        val path = uri.path?.removePrefix("/") ?: return null
        if (path.isBlank()) return null

        val decodedLabel = try {
            URLDecoder.decode(path, StandardCharsets.UTF_8.name())
        } catch (_: Exception) { path }

        val issuerParam = uri.getQueryParameter("issuer").orEmpty().trim()
        val (labelIssuer, labelAccount) = if (decodedLabel.contains(":")) {
            decodedLabel.substringBefore(":").trim() to decodedLabel.substringAfter(":", "").trim()
        } else "" to decodedLabel.trim()

        val issuer = issuerParam.ifBlank { labelIssuer }
        val account = labelAccount.ifBlank { decodedLabel }
        val algorithm = uri.getQueryParameter("algorithm")?.uppercase() ?: "SHA1"
        if (algorithm !in setOf("SHA1", "SHA256", "SHA512")) return null

        val digits = uri.getQueryParameter("digits")?.toIntOrNull() ?: 6
        if (digits !in setOf(6, 8)) return null

        val period = uri.getQueryParameter("period")?.toIntOrNull() ?: 30
        if (period <= 0 || period > 3600) return null

        return OtpAccount(
            id = "${issuer}|${account}|${secret}".hashCode().toString(),
            secret = secret.uppercase(),
            issuer = issuer,
            account = account,
            algorithm = algorithm,
            digits = digits,
            period = period
        )
    }
}
