package com.quick2fa.authenticator

import android.net.Uri
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

object OtpUriParser {
    /**
     * Accepts either a complete otpauth://totp/... URI or a Base32 secret copied/shared by itself.
     */
    fun parse(raw: String): OtpAccount? {
        val cleaned = raw.trim()
        if (cleaned.isEmpty()) return null

        // Some apps share a sentence containing the otpauth URI. Extract the URI if present.
        val uriStart = cleaned.indexOf("otpauth://", ignoreCase = true)
        if (uriStart >= 0) {
            val embedded = cleaned.substring(uriStart).trim()
            // Share providers sometimes append a label, punctuation, or a newline
            // after the URI. Try the complete value first, then a conservative
            // candidate ending at whitespace.
            parseUri(embedded)?.let { return it }
            val candidate = embedded.split(Regex("\\s+"), limit = 2)[0].trimEnd('.', ',', ';')
            parseUri(candidate)?.let { return it }
        }

        // Also accept a secret-only share/copy.
        return parseSecretOnly(cleaned)
    }

    private fun parseUri(raw: String): OtpAccount? {
        val value = raw.trim().trimEnd('.', ',', ';')
        val uri = try { Uri.parse(value) } catch (_: Exception) { return null }
        if (!uri.scheme.equals("otpauth", true) || !uri.host.equals("totp", true)) return null

        // Read the secret normally first. If a share provider encoded or
        // formatted the query unusually, fall back to extracting the secret
        // parameter directly from the raw query.
        val rawSecret = uri.getQueryParameter("secret")
            ?: uri.queryParameterNames.firstOrNull { it.equals("secret", true) }?.let { uri.getQueryParameter(it) }
            ?: Regex("(?:^|&)secret=([^&]+)", RegexOption.IGNORE_CASE).find(uri.encodedQuery.orEmpty())?.groupValues?.get(1)?.let {
                try { URLDecoder.decode(it, StandardCharsets.UTF_8.name()) } catch (_: Exception) { it }
            }
            ?: return null
        val secret = normalizeSecret(rawSecret) ?: return null

        val path = uri.path?.removePrefix("/") ?: return null
        if (path.isBlank()) return null

        val decodedLabel = try {
            URLDecoder.decode(path, StandardCharsets.UTF_8.name())
        } catch (_: Exception) { path }

        val issuerParam = uri.getQueryParameter("issuer").orEmpty().trim()
        val (labelIssuer, labelAccount) = if (decodedLabel.contains(":")) {
            decodedLabel.substringBefore(":").trim() to decodedLabel.substringAfter(":", "").trim()
        } else "" to decodedLabel.trim()

        val issuer = issuerParam.ifBlank { labelIssuer }
        val account = labelAccount.ifBlank { decodedLabel.trim() }
        val algorithm = uri.getQueryParameter("algorithm")?.uppercase() ?: "SHA1"
        if (algorithm !in setOf("SHA1", "SHA256", "SHA512")) return null

        val digits = uri.getQueryParameter("digits")?.toIntOrNull() ?: 6
        if (digits !in setOf(6, 8)) return null

        val period = uri.getQueryParameter("period")?.toIntOrNull() ?: 30
        if (period <= 0 || period > 3600) return null

        return OtpAccount(
            id = "${issuer}|${account}|${secret}".hashCode().toString(),
            secret = secret,
            issuer = issuer,
            account = account,
            algorithm = algorithm,
            digits = digits,
            period = period,
            authUri = raw.trim()
        )
    }

    private fun parseSecretOnly(raw: String): OtpAccount? {
        val secret = normalizeSecret(raw) ?: return null
        return OtpAccount(
            id = "Shared TOTP|Shared account|$secret".hashCode().toString(),
            secret = secret,
            issuer = "Shared TOTP",
            account = "Shared account",
            algorithm = "SHA1",
            digits = 6,
            period = 30
        )
    }

    private fun normalizeSecret(raw: String): String? {
        val secret = raw.replace(Regex("[\\s-]"), "").uppercase()
        if (secret.length < 8) return null
        if (!secret.matches(Regex("^[A-Z2-7]+=*$"))) return null
        return secret
    }
}
