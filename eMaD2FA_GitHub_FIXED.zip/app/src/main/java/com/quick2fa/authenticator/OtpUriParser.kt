package com.quick2fa.authenticator

import android.net.Uri
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

object OtpUriParser {
    /**
     * Accepts a complete otpauth://totp URI or a Base32 secret shared by itself.
     * Share targets on different Android/OEM apps are not consistent about how
     * they encode EXTRA_TEXT, so parsing is deliberately tolerant here.
     */
    fun parse(raw: String): OtpAccount? {
        val cleaned = raw.trim()
        if (cleaned.isEmpty()) return null

        val start = cleaned.indexOf("otpauth://", ignoreCase = true)
        if (start >= 0) {
            val embedded = cleaned.substring(start).trim()
            parseUriCandidate(embedded)?.let { return it }

            // Try a URI ending before common trailing text/punctuation.
            val candidates = buildList {
                add(embedded.trimEnd('.', ',', ';', ' ', '\n', '\r', '\t'))
                add(embedded.split(Regex("\\s+"), limit = 2)[0].trimEnd('.', ',', ';'))
            }.distinct()
            for (candidate in candidates) {
                parseUriCandidate(candidate)?.let { return it }
            }

            // Last-resort extraction of the secret directly from the shared text.
            extractSecretFromText(embedded)?.let { secret ->
                return buildAccount(secret = secret, authUri = embedded)
            }
        }

        return parseSecretOnly(cleaned)
    }

    private fun parseUriCandidate(raw: String): OtpAccount? {
        val value = raw.trim().trimEnd('.', ',', ';')
        val uri = try { Uri.parse(value) } catch (_: Exception) { return null }
        if (!uri.scheme.equals("otpauth", true) || !uri.host.equals("totp", true)) return null

        val secret = extractSecretFromUri(uri, value) ?: return null

        val decodedLabel = decode(uri.path?.removePrefix("/").orEmpty()).trim()
        val issuerParam = decode(uri.getQueryParameter("issuer").orEmpty()).trim()
        val (labelIssuer, labelAccount) = if (decodedLabel.contains(":")) {
            decodedLabel.substringBefore(":").trim() to decodedLabel.substringAfter(":").trim()
        } else {
            "" to decodedLabel
        }

        val issuer = issuerParam.ifBlank { labelIssuer }
        val account = labelAccount.ifBlank { decodedLabel }

        val algorithm = decode(uri.getQueryParameter("algorithm").orEmpty())
            .ifBlank { "SHA1" }.uppercase()
        if (algorithm !in setOf("SHA1", "SHA256", "SHA512")) return null

        val digits = uri.getQueryParameter("digits")?.toIntOrNull() ?: 6
        if (digits !in setOf(6, 8)) return null

        val period = uri.getQueryParameter("period")?.toIntOrNull() ?: 30
        if (period <= 0 || period > 3600) return null

        return buildAccount(secret, issuer, account, algorithm, digits, period, value)
    }

    private fun extractSecretFromUri(uri: Uri, rawUri: String): String? {
        // Normal Android Uri decoding.
        uri.queryParameterNames.firstOrNull { it.equals("secret", true) }?.let { key ->
            normalizeSecret(uri.getQueryParameter(key).orEmpty())?.let { return it }
        }

        // Direct extraction handles share providers that percent-encode the
        // query string in an unusual way.
        val query = rawUri.substringAfter('?', "")
        val match = Regex("(?:^|&)secret=([^&#\\s]+)", RegexOption.IGNORE_CASE).find(query)
        if (match != null) {
            val value = decode(match.groupValues[1])
            normalizeSecret(value)?.let { return it }
        }

        return null
    }

    private fun extractSecretFromText(text: String): String? {
        val match = Regex("(?:[?&]secret=)([^&#\\s]+)", RegexOption.IGNORE_CASE).find(text)
            ?: return null
        return normalizeSecret(decode(match.groupValues[1]))
    }

    private fun parseSecretOnly(raw: String): OtpAccount? {
        val secret = normalizeSecret(raw) ?: return null
        return buildAccount(secret = secret, authUri = null)
    }

    private fun buildAccount(
        secret: String,
        issuer: String = "Shared TOTP",
        account: String = "Shared account",
        algorithm: String = "SHA1",
        digits: Int = 6,
        period: Int = 30,
        authUri: String? = null
    ): OtpAccount {
        return OtpAccount(
            id = "${issuer}|${account}|$secret".hashCode().toString(),
            secret = secret,
            issuer = issuer,
            account = account,
            algorithm = algorithm,
            digits = digits,
            period = period,
            authUri = authUri
        )
    }

    private fun normalizeSecret(raw: String): String? {
        var secret = decode(raw).trim()
        // Some share providers turn '+' into a space. Spaces are not part of
        // Base32, so remove whitespace/hyphens before validation.
        secret = secret.replace(Regex("[\\s-]"), "").uppercase()
        if (secret.length < 8) return null
        if (!secret.matches(Regex("^[A-Z2-7]+=*$"))) return null
        return secret
    }

    private fun decode(value: String): String {
        return try {
            URLDecoder.decode(value, StandardCharsets.UTF_8.name())
        } catch (_: Exception) {
            value
        }
    }
}
