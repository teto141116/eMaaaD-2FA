package com.quick2fa.authenticator

import android.net.Uri
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

object OtpUriParser {
    /**
     * Accepts either a complete otpauth://totp/... URI or a Base32 secret copied/shared by itself.
     */
    fun parse(raw: String): OtpAccount? {
        val cleaned = raw.trim()
        if (cleaned.isEmpty()) return null

        // Some apps share a sentence containing the otpauth URI. Extract the URI if present.
        val uriStart = cleaned.indexOf("otpauth://", ignoreCase = true)
        if (uriStart >= 0) {
            val candidate = cleaned.substring(uriStart).trim().split(Regex("\\s+"), limit = 2)[0]
            parseUri(candidate)?.let { return it }
            parseUri(cleaned.substring(uriStart).trim())?.let { return it }
        }

        // Also accept a secret-only share/copy.
        return parseSecretOnly(cleaned)
    }

    private fun parseUri(raw: String): OtpAccount? {
        val uri = try { Uri.parse(raw.trim()) } catch (_: Exception) { return null }
        if (!uri.scheme.equals("otpauth", true) || !uri.host.equals("totp", true)) return null

        val secret = normalizeSecret(uri.getQueryParameter("secret") ?: return null) ?: return null

        val path = uri.path?.removePrefix("/") ?: return null
        if (path.isBlank()) return null

        val decodedLabel = try {
            URLDecoder.decode(path, StandardCharsets.UTF_8.name())
        } catch (_: Exception) { path }

        val issuerParam = uri.getQueryParameter("issuer").orEmpty().trim()
        val (labelIssuer, labelAccount) = if (decodedLabel.contains(":")) {
            decodedLabel.substringBefore(":").trim() to decodedLabel.substringAfter(":", "").trim()
        } else "" to decodedLabel.trim()

        val issuer = issuerParam.ifBlank { labelIssuer }
        val account = labelAccount.ifBlank { decodedLabel.trim() }
        val algorithm = uri.getQueryParameter("algorithm")?.uppercase() ?: "SHA1"
        if (algorithm !in setOf("SHA1", "SHA256", "SHA512")) return null

        val digits = uri.getQueryParameter("digits")?.toIntOrNull() ?: 6
        if (digits !in setOf(6, 8)) return null

        val period = uri.getQueryParameter("period")?.toIntOrNull() ?: 30
        if (period <= 0 || period > 3600) return null

        return OtpAccount(
            id = "${issuer}|${account}|${secret}".hashCode().toString(),
            secret = secret,
            issuer = issuer,
            account = account,
            algorithm = algorithm,
            digits = digits,
            period = period
        )
    }

    private fun parseSecretOnly(raw: String): OtpAccount? {
        val secret = normalizeSecret(raw) ?: return null
        return OtpAccount(
            id = "Shared TOTP|Shared account|$secret".hashCode().toString(),
            secret = secret,
            issuer = "Shared TOTP",
            account = "Shared account",
            algorithm = "SHA1",
            digits = 6,
            period = 30
        )
    }

    private fun normalizeSecret(raw: String): String? {
        val secret = raw.replace(Regex("[\\s-]"), "").uppercase()
        if (secret.length < 8) return null
        if (!secret.matches(Regex("^[A-Z2-7]+=*$"))) return null
        return secret
    }
}
