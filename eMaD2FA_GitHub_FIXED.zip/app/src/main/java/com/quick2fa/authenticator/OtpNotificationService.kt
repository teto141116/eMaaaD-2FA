package com.quick2fa.authenticator

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/**
 * Keeps the shared TOTP notification synchronized with the same clock used by
 * the authenticator screen. The notification is refreshed every second so the
 * displayed countdown and the code change at the exact TOTP boundary.
 */
class OtpNotificationService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var accountId: String? = null
    private var currentAccount: OtpAccount? = null

    private val updater = object : Runnable {
        override fun run() {
            updateNotification()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Notifications.createChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        accountId = intent?.getStringExtra(EXTRA_ACCOUNT_ID) ?: accountId

        val account = loadAccount() ?: run {
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildNotification(account)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                Notifications.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(Notifications.NOTIFICATION_ID, notification)
        }

        handler.removeCallbacks(updater)
        handler.post(updater)
        return START_NOT_STICKY
    }

    private fun updateNotification() {
        if (!Prefs(this).monitoring) {
            stopSelf()
            return
        }

        val account = currentAccount ?: run {
            stopSelf()
            return
        }

        NotificationManagerCompat.from(this).notify(
            Notifications.NOTIFICATION_ID,
            buildNotification(account)
        )
    }

    private fun loadAccount(): OtpAccount? {
        val id = accountId ?: return null
        val account = SecureStore(this).loadAccounts().firstOrNull { it.id == id }
        currentAccount = account
        return account
    }

    private fun buildNotification(account: OtpAccount): android.app.Notification {
        val now = System.currentTimeMillis()
        val remaining = account.period - ((now / 1000L) % account.period)
        return Notifications.notification(
            this,
            Totp.code(account, now),
            remaining,
            account
        )
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        currentAccount = null
        accountId = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val EXTRA_ACCOUNT_ID = "account_id"

        fun start(context: Context, account: OtpAccount) {
            val intent = Intent(context, OtpNotificationService::class.java)
                .putExtra(EXTRA_ACCOUNT_ID, account.id)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OtpNotificationService::class.java))
            NotificationManagerCompat.from(context).cancel(Notifications.NOTIFICATION_ID)
        }
    }
}
