package com.quick2fa.authenticator

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * Transparent share target. It receives a shared TOTP URI/secret, starts the
 * live notification service, and immediately finishes so the user remains in
 * the app they shared from.
 */
class ShareReceiverActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleShare(intent)
        finish()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) handleShare(intent)
        finish()
    }

    private fun handleShare(intent: Intent) {
        val raw = when (intent.action) {
            Intent.ACTION_SEND -> {
                intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                    ?: intent.dataString
            }
            Intent.ACTION_VIEW -> intent.dataString
            else -> null
        }?.trim() ?: return

        val prefs = Prefs(this)
        if (!prefs.monitoring) {
            OtpNotificationService.stop(this)
            Notifications.cancel(this)
            return
        }

        val account = OtpUriParser.parse(raw) ?: return
        val store = SecureStore(this)
        store.saveAccounts(store.loadAccounts().filterNot { it.id == account.id } + account)

        Notifications.createChannel(this)
        val now = System.currentTimeMillis()
        val remaining = account.period - ((now / 1000L) % account.period)
        androidx.core.app.NotificationManagerCompat.from(this).notify(
            Notifications.NOTIFICATION_ID,
            Notifications.notification(this, Totp.code(account, now), remaining, account)
        )
        OtpNotificationService.start(this, account)
    }
}
