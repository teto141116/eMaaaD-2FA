package com.quick2fa.authenticator

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

/**
 * Invisible Share target. It accepts the shared OTP URI/secret, saves it,
 * posts the notification immediately, then starts the live updater service.
 *
 * Share providers are inconsistent: some put the useful value in EXTRA_TEXT,
 * some in data, and some in ClipData. We therefore try every available value
 * instead of assuming the first value is the OTP.
 */
class ShareReceiverActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleShare(intent)
        finish()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) handleShare(intent)
        finish()
    }

    private fun handleShare(intent: Intent) {
        val prefs = Prefs(this)
        if (!prefs.monitoring) return

        val account = findAccountFromShare(intent)
        if (account == null) {
            Toast.makeText(this, "Invalid TOTP link or secret", Toast.LENGTH_SHORT).show()
            return
        }

        val store = SecureStore(this)
        store.saveAccounts(store.loadAccounts().filterNot { it.id == account.id } + account)

        // The notification is posted while this Activity is foreground.
        // This makes the Share path independent of the foreground-service start.
        Notifications.createChannel(this)
        val notifications = NotificationManagerCompat.from(this)
        if (notifications.areNotificationsEnabled()) {
            val now = System.currentTimeMillis()
            val remaining = account.period - ((now / 1000L) % account.period)
            notifications.notify(
                Notifications.NOTIFICATION_ID,
                Notifications.notification(this, Totp.code(account, now), remaining, account)
            )
        } else if (android.os.Build.VERSION.SDK_INT >= 33) {
            Toast.makeText(this, "Notifications are disabled for eMaD 2FA", Toast.LENGTH_SHORT).show()
        }

        try {
            OtpNotificationService.start(this, account)
        } catch (_: Exception) {
            // The immediate notification above remains visible even if the OEM
            // rejects the foreground-service start.
        }
    }

    private fun findAccountFromShare(intent: Intent): OtpAccount? {
        // Try every possible shared value. A few share providers put a label or
        // unrelated text in EXTRA_TEXT while the actual URI is in ClipData.
        val candidates = ArrayList<String>()

        intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()?.let {
            if (it.isNotBlank()) candidates.add(it)
        }

        intent.dataString?.let {
            if (it.isNotBlank()) candidates.add(it)
        }

        intent.getStringExtra(Intent.EXTRA_HTML_TEXT)?.let {
            if (it.isNotBlank()) candidates.add(it)
        }

        val clip: ClipData? = intent.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                val item = clip.getItemAt(i)
                item.text?.toString()?.let {
                    if (it.isNotBlank()) candidates.add(it)
                }
                item.uri?.toString()?.let {
                    if (it.isNotBlank()) candidates.add(it)
                }
                try {
                    item.coerceToText(this)?.toString()?.let {
                        if (it.isNotBlank()) candidates.add(it)
                    }
                } catch (_: Exception) {
                }
            }
        }

        // De-duplicate while preserving the provider's order.
        for (candidate in candidates.distinct()) {
            OtpUriParser.parse(candidate.trim())?.let { return it }
        }

        return null
    }
}
