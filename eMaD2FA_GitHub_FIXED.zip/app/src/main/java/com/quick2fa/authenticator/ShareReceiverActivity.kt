package com.quick2fa.authenticator

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

/**
 * Transparent share target. It receives a TOTP URI/secret, saves it, starts
 * the foreground notification service, and immediately returns to the app
 * the user shared from.
 */
class ShareReceiverActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleShare(intent)
        finish()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) handleShare(intent)
        finish()
    }

    private fun handleShare(intent: Intent) {
        if (!Prefs(this).monitoring) return

        val raw = extractSharedText(intent)?.trim().orEmpty()
        if (raw.isBlank()) return

        val account = OtpUriParser.parse(raw)
        if (account == null) {
            Toast.makeText(this, "Invalid TOTP link or secret", Toast.LENGTH_SHORT).show()
            return
        }

        val store = SecureStore(this)
        store.saveAccounts(store.loadAccounts().filterNot { it.id == account.id } + account)

        // The foreground service is now responsible for the notification.
        // Starting it first avoids a race between a temporary notification and
        // the foreground-service notification when the share activity closes.
        try {
            OtpNotificationService.start(this, account)
        } catch (_: Exception) {
            // Fallback: still try to display the OTP immediately if the OEM
            // rejects the foreground-service start.
            if (NotificationManagerCompat.from(this).areNotificationsEnabled()) {
                val now = System.currentTimeMillis()
                val remaining = account.period - ((now / 1000L) % account.period)
                NotificationManagerCompat.from(this).notify(
                    Notifications.NOTIFICATION_ID,
                    Notifications.notification(this, Totp.code(account, now), remaining, account)
                )
            }
        }
    }

    private fun extractSharedText(intent: Intent): String? {
        // Normal Android Share flow.
        intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()?.let { return it }

        // Some apps put the shared URI in data instead of EXTRA_TEXT.
        intent.dataString?.let { return it }

        // Some share implementations expose text through ClipData.
        val clip: ClipData? = intent.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                clip.getItemAt(i).coerceToText(this)?.toString()?.let { text ->
                    if (text.isNotBlank()) return text
                }
            }
        }

        return null
    }
}
